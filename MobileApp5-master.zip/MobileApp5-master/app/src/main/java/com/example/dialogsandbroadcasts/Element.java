package com.example.dialogsandbroadcasts;

public class Element {
    private int number;
    private int color;

    public Element(int number, int color) {
        this.number = number;
        this.color = color;
    }
    public int getNumber() {
        return number;
    }

    public int getColor() {
        return color;
    }
}
